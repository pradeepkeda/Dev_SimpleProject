package PageObjects.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import PageObjects.BasePage;

public class EdiAssist extends BasePage {

	private By Radio_EDAssist = By.xpath("//a[normalize-space(text())='EdAssist Solutions for Employers']");

	private By ButtonLearnMore = By.xpath("(//a[normalize-space(text())='Learn More'])[4]");

	public static By BHLogo = By.cssSelector("app-bh-logo");

	public EdiAssist(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public String HomePageTitle() {
		return driver.getTitle();

	}

	public void VerifyIfPageIsAvailable() {

		AcceptCookies();

		WaitUntilElementAppear(BHLogo);

	}

	public void VerifyRadioButtonEDAssistIsAvailable() {

		WaitUntilElementAppear(Radio_EDAssist);

		System.out.println("Radio_EDAssist is visible");

	}

	public void ClickRadio_EDAssist() {

		driver.findElement(Radio_EDAssist).click();

		System.out.println("Radio_EDAssist is Clicked");

	}

	public void VerifyButtonLearnMoreIsAvailable() {

		WaitUntilElementAppear(ButtonLearnMore);

		System.out.println("ButtonLearnMore is visible");

	}

	public void ClickButtonLearnMore() {

		driver.findElement(ButtonLearnMore).click();

		System.out.println("ButtonLearnMore is Clicked");

	}

}
