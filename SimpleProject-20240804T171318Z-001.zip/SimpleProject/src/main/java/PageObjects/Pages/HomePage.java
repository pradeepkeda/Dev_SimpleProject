package PageObjects.Pages;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import PageObjects.BasePage;
import dev.failsafe.internal.util.Assert;
import static Utilities.GlobalParamsFactory.*;

import java.util.ArrayList;
import java.util.List;

public class HomePage extends BasePage {
	private By BHLogo = By.cssSelector("app-bh-logo");
	private By Radio_EDAssist = By.xpath("//a[normalize-space(text())='EdAssist Solutions for Employers']");
	private By ButtonLearnMore = By.xpath("(//a[normalize-space(text())='Learn More'])[4]");
	private By SlickDots = By.xpath("//ul[@class='slick-dots']");
	private By SearchIcon = By.xpath("(//a[@class='nav-link-search track_nav_interact'])[1]");
	private By SearchInputBox = By.xpath("(//button[contains(text(), 'Search')])[2]/../input");
	private By SearchButton = By.xpath("(//button[text()='Search'])[2]");
	private By Testimonial = By.xpath("//div[@class='slick-slide']");
	private By FirstSearchResult = By.xpath("//h3[text()='Employee Education in 2018: Strategies to Watch']");

	public HomePage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}

	public void VerifyIfPageIsAvailable() {
		AcceptCookies();
		WaitUntilElementAppear(BHLogo);

	}
 
	public void NavigateToSpecificURL() {

		driver.navigate().to(BaseUrl);

	}

	public void NavigateToNewTab() {

		driver.findElement(BHLogo).click();

	}

	public void CheckNewTab() {

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());

		driver.switchTo().window(tabs.get(1));

	}

	public void ClickRadio_EDAssist() {

		driver.findElement(Radio_EDAssist).click();

	}

	public void VerifyButtonLearnMoreIsAvailable() {

		WaitUntilElementAppear(ButtonLearnMore);

	}

	public void VerifyRadioButtonEDAssistIsAvailable() {

		WaitUntilElementAppear(Radio_EDAssist);

	}

	public void ClickButtonLearnMore() {

		driver.findElement(ButtonLearnMore).click();

	}

	public void CheckURLContainsEdAssistSolutions() {

		String currentURL = driver.getCurrentUrl();

		if (currentURL.contains("edassist-solutions")) {

			System.out.println("The URL contains 'edassist-solutions'.");

		} else {

			System.out.println("The URL does not contain 'edassist-solutions'.");

		}

	}

	public void VerifyCommentSlicksDotsIsVisible() {

		WaitUntilElementAppear(SlickDots);

	}

	public void CalculateSlickDots() {

		WebElement ulElement = driver.findElement(SlickDots);

		List<WebElement> liElements = ulElement.findElements(By.tagName("li"));

		int count_slickdots = liElements.size();

		System.out.println("Count of slick dots are:- " + count_slickdots);

		List<WebElement> testimonialElements = driver.findElements(Testimonial);

		int countTestimonial1 = testimonialElements.size();

		System.out.println("Count of Testimonial is:- " + countTestimonial1);
		
		Assertions.assertEquals(count_slickdots, countTestimonial1,"No of comments are same same as dot or not " );

	}

	public void VerifySearchResult() throws InterruptedException {

		String expectedElement = "Employee Education in 2018: Strategies to Watch";

		WaitUntilElementAppear(SearchIcon);

		driver.findElement(SearchIcon).click();

		boolean isElementVisible = driver.findElement(SearchInputBox).isDisplayed();
		
		Assertions.assertTrue(isElementVisible);

		driver.findElement(SearchInputBox).sendKeys("Employee Education in 2018: Strategies to Watch");

		driver.findElement(SearchButton).click();

		String actualElement = driver.findElement(FirstSearchResult).getText();
		
//		if (actualElement.equalsIgnoreCase(expectedElement)) {
//
//			System.out.println("PASS :: Search result is exact match");
//
//		}
//
//		else {
//
//			System.out.println("FAIL : Search result is not matched");
//
//		}
		Assertions.assertEquals(actualElement, expectedElement,"Search result is exact match " );

	}
}
