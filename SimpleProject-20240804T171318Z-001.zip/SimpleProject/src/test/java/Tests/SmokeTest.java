package Tests;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import Utilities.BaseTest;

public class SmokeTest extends BaseTest {

	@Test
	@Order(1)
	public void VerifyIfPageIsAvailable() throws InterruptedException {
		homePage.NavigateToSpecificURL();
		Thread.sleep(10000);
		homePage.VerifyIfPageIsAvailable();

	}

	@Test
	@Order(2)
	public void VerifyComments() throws InterruptedException {

		homePage.NavigateToSpecificURL();

		homePage.VerifyIfPageIsAvailable();

		homePage.NavigateToNewTab();

		homePage.CheckNewTab();

		homePage.VerifyRadioButtonEDAssistIsAvailable();

		homePage.ClickRadio_EDAssist();

		homePage.VerifyButtonLearnMoreIsAvailable();

		homePage.ClickRadio_EDAssist();

		homePage.VerifyButtonLearnMoreIsAvailable();

		homePage.ClickButtonLearnMore();

		homePage.CheckURLContainsEdAssistSolutions();

		homePage.VerifyCommentSlicksDotsIsVisible();

		homePage.CalculateSlickDots();

	}

	@Test
	@Order(3)
	public void VerifySearchFunctionality() throws InterruptedException {

		homePage.NavigateToSpecificURL();

		homePage.VerifyIfPageIsAvailable();
		Thread.sleep(10000);
		homePage.NavigateToNewTab();
		Thread.sleep(10000);
		homePage.CheckNewTab();
		Thread.sleep(10000);
		homePage.VerifySearchResult();

	}

}
